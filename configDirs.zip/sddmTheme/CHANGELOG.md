2019-06-14
----------
- Added Hibernation support (@MarcinOrlowski)
